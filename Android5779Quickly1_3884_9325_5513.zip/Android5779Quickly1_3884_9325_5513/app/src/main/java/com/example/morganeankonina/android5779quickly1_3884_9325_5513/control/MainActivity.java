package com.example.morganeankonina.android5779quickly1_3884_9325_5513.control;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.morganeankonina.android5779quickly1_3884_9325_5513.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/**
 * Operations on button that transfer to add travel
 */
        FloatingActionButton fabGoTo = (FloatingActionButton) findViewById(R.id.GoTofab);
        fabGoTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goTo = new Intent(MainActivity.this,GoTo.class);
                startActivity(goTo);
                Snackbar.make(view, "Your navigation", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        /**
         * Operations on button that call Taxi phone help
         */
        FloatingActionButton call = (FloatingActionButton) findViewById(R.id.GPSfab);
        call.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+"0586808006"));
            startActivity(intent);
        }
    });
}
}


