package com.example.morganeankonina.android5779quickly1_3884_9325_5513.model.backend;

import com.example.morganeankonina.android5779quickly1_3884_9325_5513.entities.Travel;

public interface Backend {

    /**
     *
     * @param travel
     * @throws Exception
     */
    public void addTravel(Travel travel) throws Exception;
}
