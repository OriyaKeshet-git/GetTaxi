package com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend;

import android.content.Context;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;

import java.util.ArrayList;
import java.util.Date;

public interface Backend {
    //function travels
    public ArrayList<Travel> getTravels();
    public ArrayList<Travel> getAvailableTravel();
    public ArrayList<Travel> getFinsishTravel();
    public ArrayList<Travel> getTravelDriver(String driverId);
    public ArrayList<Travel> getTravelCity(String city);
    public void updateTravel(final Travel toUpdate);
    //function drivers
    public void addDriver(Driver driver) throws Exception;
    public ArrayList<Driver> getDrivers();
    public ArrayList<Driver> getNamesDrivers(String driverName);
    public ArrayList<Travel> getAvailableTravelKm(Context context, String driver, int km);
}

