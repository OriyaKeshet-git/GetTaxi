package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Vibrator;
import android.widget.Toast;

public class MyBroadcastReceiver extends BroadcastReceiver {

    /**
     * function onReceive to receive broadcast receiver from an intent of the broadcast
     * @param context
     * @param intent
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        //where the boot is completed
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())){
            Toast.makeText(context, "Boot completed", Toast.LENGTH_LONG).show();
        }
        //where the connectivity is changed
        if(ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())){
            Toast.makeText(context, "Connectivity change", Toast.LENGTH_LONG).show();
        }
        //where the airplane mode is changed
        if(Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())){
            Toast.makeText(context, "Airplane connectivity", Toast.LENGTH_LONG).show();
        }
        //after the toast the phone will vibrate 5000 milliseconds
        Vibrator vibrator;
        vibrator=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(5000);

    }
}
