package com.example.morganeankonina.android5779quickly_3884_9325_5513.model.datasource;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DataBaseFB implements Backend {
    /**
     * ctor
     */
    public DataBaseFB() {
        //start listener
        notifyToDriverList(new DataBaseFB.NotifyDataChange<ArrayList<Driver>>() {
            @Override
            public void onDataChanged(ArrayList<Driver> obj) {
            }
            @Override
            public void onFailure(Exception e) { }
        });
    }

    public interface NotifyDataChange<T> {
        void onDataChanged(T obj);
        void onFailure(Exception exception);
    }

    //define reference to database and array list of travels and drivers
    static DatabaseReference travelsRef;
    static ArrayList<Travel> travelsList;
    static DatabaseReference driversRef;
    static ArrayList<Driver> driversList;

    static {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        travelsRef = database.getReference("Travel");
        driversRef = database.getReference("Driver");
        travelsList = new ArrayList<>();
        driversList = new ArrayList<>();
    }

    /**
     * function getTravels to get all travels
     * @return list of travels
     */
    @Override
    public ArrayList<Travel> getTravels() {
        return travelsList;
    }

    /**
     * function getAvailableTravel to get all available travels: state=TREATMENT
     * @return list of available travels
     */
    @Override
    public ArrayList<Travel> getAvailableTravel() {
        //define three travels and add them to array list to check
        ArrayList<Travel>availableTravel=new ArrayList<>();
        Travel travel1=new Travel(Travel.States.TREATMENT, "Ashdood","Jerusalem", "8:00","10:00", "Annaelle","0586808006","annaelle@gmail.com");
        Travel travel2=new Travel(Travel.States.FINISH, "Haifa","Ashdood", "12:00","14:00", "Morgane","0586808006","morgane@gmail.com");
        Travel travel3=new Travel(Travel.States.TREATMENT, "Tsfat","Bat Yam", "20:00","20:00", "Nethanel","0586808006","nethanel@gmail.com");
        travelsList.add(travel1);
        travelsList.add(travel2);
        travelsList.add(travel3);
        //pass of all travel and take travels in treatment
        for (Travel travel:travelsList)
        {
            if(travel.getState()== Travel.States.TREATMENT)
                availableTravel.add(travel);
        }
        return availableTravel;
    }

    /**
     * function getFinishTravel to get all finished travels: state=FINISHED
     * @return list of finished travels
     */
    @Override
    public ArrayList<Travel> getFinsishTravel() {
        //define three travels and add them to array list to check
        ArrayList<Travel> finishTravel=new ArrayList<>();
        /*Travel travel1=new Travel(Travel.States.FINISH, "Ashdood","Jerusalem", new Time(8,00,00),new Time(10,00,00), "Annaelle","0586808006","annaelle@gmail.com");
        Travel travel2=new Travel(Travel.States.FINISH, "Haifa","Ashdood", new Time(12,00,00),new Time(14,00,00), "Morgane","0586808006","morgane@gmail.com");
        Travel travel3=new Travel(Travel.States.FINISH, "Tsfat","Bat Yam", new Time(20,00,00),new Time(22,00,00), "Nethanel","0586808006","nethanel@gmail.com");
*/
        Travel travel1=new Travel(Travel.States.FINISH, "Ashdood","Jerusalem", "8:00","10:00", "Annaelle","0586808006","annaelle@gmail.com");
        Travel travel2=new Travel(Travel.States.FINISH, "Haifa","Ashdood", "12:00","14:00", "Morgane","0586808006","morgane@gmail.com");
        Travel travel3=new Travel(Travel.States.FINISH, "Tsfat","Bat Yam", "20:00","20:00", "Nethanel","0586808006","nethanel@gmail.com");

        travelsList.add(travel1);
        travelsList.add(travel2);
        travelsList.add(travel3);
        //pass of all travel and take travels finished
        for (Travel travel:travelsList)
        {
            if(travel.getState()== Travel.States.FINISH)
                finishTravel.add(travel);
        }
        return finishTravel;
    }

    /**
     * function getTravelDriver to get all travels of driver
     * @param driverId
     * @return list of driver's travels
     */
    @Override
    public ArrayList<Travel> getTravelDriver(String driverId) {
        ArrayList<Travel> travelsDrivers=new ArrayList<>();
        //pass of all travels and take travels of a specific driver
        for (Travel travel:travelsList)
        {
            if(driverId.equals(travel.getId()))
                travelsDrivers.add(travel);
        }
        return travelsDrivers;
    }

    /**
     * function getTravelCity to get all travels in function city
     * @param driverCity
     * @return list of travels in function of city
     */
    @Override
    public ArrayList<Travel> getTravelCity(String driverCity) {
        ArrayList<Travel> travelsCityDrivers=new ArrayList<>();
        for (Travel travel:travelsList)
        {
            if(driverCity.equals(travel.getStartLocation()))
                travelsCityDrivers.add(travel);
        }
        return travelsCityDrivers;
    }

    /**
     * function addDriver to add driver to firebase
     * @param driver
     */
    @Override
    public void addDriver(Driver driver) throws Exception{
        String key = driver.getId();
        //driversRef.setValue("Hello, World!");
        //pass of all driver and checks if driver is not already exist in firebase
        for (Driver d : driversList) {
            //if (d.getPassword().equals(driver.getPassword()) && d.getUsername().equals(driver.getUsername())) {
            if(d.equals(driver))
                throw new Exception("This user is already exist! Please enter another information!");
        }
        //enter this new driver in firebase
        driversRef.child(key).setValue(driver);
        //driversRef.child(key).setValue(driver.toString());
        //driversRef.child(key).setValue(driver);

    }

    /**
     * function getDrivers to get al drivers
     * @return list of all drivers
     */
    @Override
    public ArrayList<Driver> getDrivers() {
        return driversList;
    }

    /**
     * function getNamesDrivers to get all driver with the same name
     * @param driverName
     * @return list of drivers with specific name
     */
    @Override
    public ArrayList<Driver> getNamesDrivers(String driverName) {
       ArrayList<Driver> nameDrivers=new ArrayList<>();
       //pass of all drivers in direbase and take all drivers with a specific name
       for(Driver driver:driversList)
       {
           if (driverName.equals(driver.getName()))
               nameDrivers.add(driver);
       }
       return nameDrivers;
    }

    /**
     * function getAvailablelTravelKm to get all travels in function of a specific distance in km
     * @param context
     * @param driverLocation
     * @param km
     * @return list of travels in function of a specific distance in km
     */
    @Override
    public ArrayList<Travel> getAvailableTravelKm(Context context, String driverLocation, int km) {
        ArrayList<Travel> travelsKm=new ArrayList<Travel>();
        //all travels whose are in treatment
        ArrayList<Travel> availableTravel=getAvailableTravel();
        //pass of all travel and take all travel whose distance in <= number of km
        for(Travel travel : availableTravel)
        {
            if(distance(context,driverLocation,travel.getStartLocation())<= km)
                travelsKm.add(travel);
        }
        return travelsKm;
    }
    /**
     * function distance to calculate the distance between client's location and driver's location
     * @param context
     * @param driverLocation
     * @param startLocation
     * @return distance between client's location and driver's location
     */
    private float distance(Context context, String driverLocation, String startLocation)
    {
        try {
            Location locationA=locationFromString(context,driverLocation);
            Location locationB=locationFromString(context,startLocation);
            return (locationA.distanceTo(locationB))/1000;
        }
        catch (Exception e)
        {
            Toast.makeText(context, "ERROR", Toast.LENGTH_SHORT).show();
        }
        return 0;
    }

    /**
     * function locationFromString to convert the String to Location
     * @param context
     * @param myLocation
     * @return Location
     * @throws Exception
     */
    private Location locationFromString(Context context, String myLocation) throws Exception
    {
        Geocoder gc=new Geocoder(context, Locale.getDefault());
        Location locationA=null;
        if(gc.isPresent())
        {
            List<Address> list=gc.getFromLocationName(myLocation,1);
            Address address=list.get(0);
            double lat=address.getLatitude();
            double lng=address.getLongitude();
            locationA=new Location("a");
            locationA.setLatitude(lat);
            locationA.setLongitude(lng);

            return locationA;
        }
        return locationA;

    }


    //define two listener
    private static ChildEventListener travelRefChildEventListener;
    private static ChildEventListener driverRefChildEventListener;

    /**
     * function notifyToTravelList to listener of travel
     * @param notifyDataChange
     */
    public static void notifyToTravelList(final NotifyDataChange<ArrayList<Travel>> notifyDataChange) {
        if (notifyDataChange != null) {
            if (travelRefChildEventListener != null) {
                notifyDataChange.onFailure(new Exception("Change not successful"));
                return;
            }
            travelsList.clear();
            //new childEventListener
            travelRefChildEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    Travel travel = dataSnapshot.getValue(Travel.class);
                    travelsList.add(travel);
                    notifyDataChange.onDataChanged(travelsList);
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                    Travel travel = dataSnapshot.getValue(Travel.class);
                    String id = dataSnapshot.getKey();
                    for (int i = 0; i < travelsList.size(); i++) {
                        if (travelsList.get(i).getId().equals(id)) {
                            travelsList.set(i, travel);
                            break;
                        }
                    }
                    notifyDataChange.onDataChanged(travelsList);
                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    notifyDataChange.onFailure(databaseError.toException());
                }
            };
            travelsRef.addChildEventListener(travelRefChildEventListener);
        }
    }

    /**
     * fucntion stopNotifyToTravelList to stop listener to firebase
     */
    public void stopNotifyToTravelList() {
        try {
            if (travelRefChildEventListener != null) {
                travelsRef.removeEventListener(travelRefChildEventListener);//remove listener
                travelRefChildEventListener = null;
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    /**
     * function updateTravel
     * @param travelToUpdate
     */
    @Override
    public void updateTravel(final Travel travelToUpdate)
    {
        String key=travelToUpdate.getId();
        travelsRef.child(key).setValue(travelToUpdate);
    }

    /**
     * function notifyToTravelList to listener of driver
     * @param notifyDataChange
     */
    public static void notifyToDriverList(final NotifyDataChange<ArrayList<Driver>> notifyDataChange) {
        if (notifyDataChange != null) {
            if (driverRefChildEventListener != null) {//if there is already listener
                notifyDataChange.onFailure(new Exception("unNotify drivers list"));
                return;
            }
            driversList.clear();

            driverRefChildEventListener = new ChildEventListener() {//write driverRefListener event
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    Driver driver = (Driver) dataSnapshot.getValue(Driver.class);
                   driversList.add(driver);
                   notifyDataChange.onDataChanged(driversList);
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {//react when there is child changed in firebase
                    //Driver driver= (Driver) dataSnapshot.getValue();
                    //Driver driver = dataSnapshot.getValue(Driver.class);
                    Driver driver =(Driver) dataSnapshot.getValue(Driver.class);
                    String id=dataSnapshot.getKey();
                    for (int i = 0; i < driversList.size(); i++) {
                        if ((driversList.get(i).getId()).equals(id)) {
                            driversList.set(i, driver);
                            break;
                        }
                    }
                    notifyDataChange.onDataChanged(driversList);
                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {//react when there is child removed from firebase
                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    notifyDataChange.onFailure(databaseError.toException());

                }
            };
            driversRef.addChildEventListener(driverRefChildEventListener);//add driverRef the driverRefListener event
        }
    }
}
