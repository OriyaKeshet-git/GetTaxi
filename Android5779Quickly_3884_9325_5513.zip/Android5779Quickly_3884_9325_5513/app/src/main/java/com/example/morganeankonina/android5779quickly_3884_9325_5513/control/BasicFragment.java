package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link BasicFragment} interface
 * to handle interaction events.
 * create an instance of this fragment.
 */
public class BasicFragment extends Fragment {
    /**
     * default ctor of the basic fragment
     */
    public BasicFragment() {
        // Required empty public constructor
    }

    /**
     * function onCreateView to inflat ethe layout in the fragment
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_basic, container, false);
    }
}
