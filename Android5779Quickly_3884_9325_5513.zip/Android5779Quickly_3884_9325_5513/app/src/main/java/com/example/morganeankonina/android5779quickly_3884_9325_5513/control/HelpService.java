package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;


public class HelpService extends Application {
    public static final String CHANNEL_ID = "serviceChannel";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel(); //service
    }

    public void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "serviceChannel",
                     NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }
}
