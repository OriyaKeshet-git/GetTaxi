package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;

import java.io.Serializable;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Frag1} interface
 * to handle interaction events.
 * Use the {@link Frag1#} factory method to
 * create an instance of this fragment.
 */
public class Frag1 extends Fragment {
    ArrayList<Travel> travelArrayList;
    ArrayAdapter<Travel> adapter;
    ListView listView;
    Backend backend;

    /**
     * default ctor of the first fragment
     */
    public Frag1() {
        // Required empty public constructor
    }

    /**
     * function onCreateView to inflate the layout fo this fragment (frag1)
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // inflate the layout for the fragment
        View view = inflater.inflate(R.layout.fragment_frag1, container, false);

        listView = (ListView) view.findViewById(R.id.available_travels_list);

        //check if the navList is not empty so update the view to show what we select to show
        if(((NavActivity)getActivity()).navList.size()!=0) {
            travelArrayList=((NavActivity)getActivity()).navList;
            initializeList();
        }

        //update the view in function what we select in the listView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //get the travel in current position
                Travel travelSelected = travelArrayList.get(position);

                //initialize frag2
                android.support.v4.app.FragmentManager fragmentManager = getFragmentManager();
                android.support.v4.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Frag2 frag2 = new Frag2();

                //keep all information of the current travel
                Bundle bundleTravel = new Bundle();
                bundleTravel.putSerializable("select", (Serializable) travelSelected);
                frag2.setArguments(bundleTravel);

                //frag2
                fragmentTransaction.replace(R.id.contain_frag2, frag2);
                fragmentTransaction.commit();
            }
        });

        //spinner items and adapter to show them in the view
        final String[] filterItem = {"Choose", "Travels finished", "Travels with distance"};
        final Spinner spinner = (Spinner) view.findViewById(R.id.spinner_frag1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, filterItem);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        //connection the firebase
        backend = BackendFactory.getInstance(this.getActivity());

        final EditText choice = (EditText) view.findViewById(R.id.text_spinner_frag1);//the text to input
        final Button okFilter = (Button) view.findViewById(R.id.button_filter_frag1);//the button ok

        final TextView startPoint = (TextView) view.findViewById(R.id.text_start_frag1);//the start point

        /**
         * operations of item selected on the spinner

         */
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    //"Choose"- nothing to do
                    case 0: {
                        break;
                    }
                    //"Travels finished"-show all travels finished
                    case 1: {
                        //initialize the view
                        clear1();
                        //get all travels with state=finished
                        travelArrayList = backend.getFinsishTravel();
                        choice.setVisibility(View.VISIBLE);
                        ((NavActivity) getActivity()).help = "nothing";
                        //show all information
                        initializeList();
                        break;
                    }
                    //"Travels with distance"-show all travels in function on the distance
                    case 2: {
                        //initialize the view
                        clear1();
                        //the location
                        startPoint.setVisibility(View.VISIBLE);
                        ((NavActivity) getActivity()).getLocation();
                        //the input text
                        choice.setVisibility(View.VISIBLE);
                        okFilter.setVisibility(View.VISIBLE);
                        break;
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        /**
         * operation on click of button ok of the filter
         */
        okFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemSelected = spinner.getSelectedItem().toString();
                switch (itemSelected) {
                    case "Travels with distance": {
                        try{
                            //get all travels in function of the distance in km
                            travelArrayList=backend.getAvailableTravelKm(getContext(),startPoint.getText().toString(),Integer.valueOf(choice.getText().toString()));
                            //show in the view
                            initializeList();
                            //button filter ok change to invisible
                            okFilter.setVisibility(View.INVISIBLE);
                            //text input change to invisible
                            choice.setVisibility(View.INVISIBLE);
                            //text input clear
                            choice.getText().clear();
                            //text of the location change to invisible
                            startPoint.setVisibility(View.INVISIBLE);
                            startPoint.clearComposingText();
                            break;
                        }
                        catch (Exception e)
                        {
                            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        return view;
    }

    /**
     * clear the view to show new information whose were selected
     */
    private void clear1() {
        android.support.v4.app.FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        //new fragment and replace the last fragment with the fragment which was created
        BasicFragment frag = new BasicFragment();
        fragmentTransaction.replace(R.id.contain_frag2, frag);
        fragmentTransaction.commit();
    }

    /**
     * update the list view with the new information to show them in the view
     */
    private void initializeList() {
        //if the list of travels is empty-there s nothing to show
        if (travelArrayList.size() == 0) {
            adapter.clear();
            return;
        }
        //create adapter to adapt the information of travelArrayList in the view in function of the layout
        adapter = new ArrayAdapter<Travel>(getActivity(), R.layout.in_travels, travelArrayList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                //the view is empty so do nothing
                if (convertView == null) {
                    convertView = View.inflate(getActivity(), R.layout.in_travels, null);
                }
                //if the view is not empty so find all information and set them in the view
                TextView clientName = (TextView) convertView.findViewById(R.id.in_client_name);
                TextView clientState = (TextView) convertView.findViewById(R.id.in_state);
                TextView clientAddress = (TextView) convertView.findViewById(R.id.in_start);
                TextView clientPhone = (TextView) convertView.findViewById(R.id.in_client_phone);
                //the current travel to show
                Travel travelViewNow = travelArrayList.get(position);
                clientName.setText(travelViewNow.getClientName());
                clientState.setText(travelViewNow.getState().name());
                clientAddress.setText(travelViewNow.getStartLocation());
                clientPhone.setText(travelViewNow.getClientPhone());
                return convertView;
            }
        };
        listView.setAdapter(adapter);
    }
}
