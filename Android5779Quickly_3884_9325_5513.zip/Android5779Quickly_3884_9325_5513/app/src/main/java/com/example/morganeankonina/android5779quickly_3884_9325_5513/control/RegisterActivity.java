package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;

public class RegisterActivity extends AppCompatActivity {

    /**
     * fucntion onCreate to inflate the layout on the view
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //connection the firebase
        final Backend backend = BackendFactory.getInstance(this);

        final Button ok = (Button) findViewById(R.id.register_ok);
        /**
         * function setOnClickListener
         * when user click on boutton ok the user enters all information and the function adds them to database
         */
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //get all information from view
                    TextView usernameText = (TextView) findViewById(R.id.userEdit);
                    final String username = usernameText.getText().toString();

                    TextView passwordText = (TextView) findViewById(R.id.passwordEdit);
                    final String password = passwordText.getText().toString();

                    TextView lastNameText = (TextView) findViewById(R.id.LastNameEdit);
                    final String lastName = lastNameText.getText().toString();

                    TextView firstNameText = (TextView) findViewById(R.id.FirstNameEdit);
                    final String firstName = firstNameText.getText().toString();

                    TextView idText = (TextView) findViewById(R.id.IdEdit);
                    final String id = idText.getText().toString();

                    TextView phoneText = (TextView) findViewById(R.id.TelephoneEdit);
                    final String phone = phoneText.getText().toString();

                    TextView emailText = (TextView) findViewById(R.id.EmailEdit);
                    final String email = emailText.getText().toString();

                    TextView creditEdit = (TextView) findViewById(R.id.CardEdit);
                    final String credit = creditEdit.getText().toString();

                    //conditions for a validation of theh data
                    if (username.length() < 1)
                        throw new Exception("Please enter your start point!");
                    if (password.length() < 1)
                        throw new Exception("Please enter your destination!");
                    if (lastName.length() < 1)
                        throw new Exception("Please enter your name!");
                    if (firstName.length() < 1)
                        throw new Exception("Please enter your email!");
                    if (id.length() < 1)
                        throw new Exception("Please enter your email!");
                    if (phone.length() < 1)
                        throw new Exception("Please enter your email!");
                    if (email.length() < 1)
                        throw new Exception("Please enter your email!");
                    if (credit.length() < 1)
                        throw new Exception("Please enter your email!");
                    if (emailValid(email) == false)
                        throw new Exception("Your email is not valid. Please enter again!");
                    if (phoneValid(phone) == false)
                        throw new Exception("Your phone is not valid. Please enter again!");

                    //define the driver
                    final Driver driver = new Driver(username, password, lastName, firstName, id, phone, email, credit);

                    try {
                        //add this driver to database
                        backend.addDriver(driver);
                        Toast toast = Toast.makeText(getApplicationContext(), "Hey " + driver.getName() + ", your information added successufully\n\n" + driver.getName(), Toast.LENGTH_LONG);
                        toast.show();
                        //from RegisterActivity to NavActivity
                        Intent goNavMenu = new Intent(RegisterActivity.this, NavActivity.class);
                        //keep the information of this driver
                        Bundle extras = new Bundle();
                        extras.putString("username", username);
                        extras.putString("password", password);
                        goNavMenu.putExtras(extras);
                        startActivity(goNavMenu);
                    } catch (Exception e) {
                        Toast toast = Toast.makeText(getApplicationContext(), e.getMessage() + " information are not correct", Toast.LENGTH_LONG);
                        toast.show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage() + "your information are not correct", Toast.LENGTH_LONG).show();
                }
            }
        });

        FloatingActionButton call = (FloatingActionButton) findViewById(R.id.floating_call);
        /**
         * function setOnClickListener
         * when user click on boutton call: he call quickyTaxi phone
         */
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView phoneText = (TextView) findViewById(R.id.TelephoneEdit);
                final String phone = phoneText.getText().toString();

                Intent intent = new Intent(Intent.ACTION_DIAL);
                //phone to quickly taxi help
                intent.setData(Uri.parse("tel:"+"0586808006"));
                startActivity(intent);
        }
    });
    }


    /**
     * function emailValid checks if the email is valid
     *
     * @param email
     * @return boolean
     */
    public static boolean emailValid(String email) {
        if (email != null && email.trim().length() > 0)
            return email.matches("^[a-zA-Z0-9\\.\\-\\_]+@([a-zA-Z0-9\\-\\_\\.]+\\.)+([a-zA-Z]{2,4})$");
        return false;
    }

    /**
     * function phoneValid checks if the phone is valid
     *
     * @param phone
     * @return boolean
     */
    public static boolean phoneValid(String phone) {
        if (phone.length() != 10 || phone.charAt(0) != '0' || phone.charAt(1) != '5')
            return false;
        return true;
    }
}
