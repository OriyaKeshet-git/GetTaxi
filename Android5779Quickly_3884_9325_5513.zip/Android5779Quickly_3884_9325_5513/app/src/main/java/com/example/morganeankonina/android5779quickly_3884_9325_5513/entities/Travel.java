package com.example.morganeankonina.android5779quickly_3884_9325_5513.entities;

import java.io.Serializable;
//import java.util.Random;

/**
 * The Travel class describes the properties of the travel
 */
public class Travel implements Serializable{
    public static int counter=0;

    public enum States {FREE, TREATMENT, FINISH}

    private String id;
    private States state;
    private String startLocation;
    private String destination;
    private String startTime;
    private String endTime;
    private String clientName;
    private String clientPhone;
    private String clientEmail;
    public int price;

    //public Random rand = new Random();
    /**
     * default ctor
     */
    public Travel() {
        this.id=String.valueOf(++counter);

        this.state = States.FREE;
        this.startLocation = "";
        this.destination = "";
        this.startTime="";
        this.endTime="";
       // this.startTime = new Time(8,0,0);
       // this.endTime = new Time(24,0,0);
        this.clientName = "";
        this.clientPhone = "";
        this.clientEmail = "";
        //this.price=rand.nextInt(40)+10;

    }

    /**
     * ctor
     * @param state
     * @param startLocation
     * @param destination
     * @param startTime
     * @param endTime
     * @param clientName
     * @param clientPhone
     * @param clientEmail
     */
    public Travel(States state, String startLocation, String destination, String startTime, String endTime, String clientName, String clientPhone, String clientEmail) {
        this.id=String.valueOf(++counter);
        this.state = state;
        this.startLocation = startLocation;
        this.destination = destination;
        this.startTime = startTime;
        this.endTime = endTime;
        this.clientName = clientName;
        this.clientPhone = clientPhone;
        this.clientEmail = clientEmail;
        //this.price=rand.nextInt(40)+10;
    }
    /**-------------------------Getters-------------------------------------------------------------**/
    public String getId() { return id;}

    public States getState() {
        return state;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public String getDestination() {
        return destination;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getClientName() {
        return clientName;
    }

    public String getClientPhone() {
        return clientPhone;
    }

    public String getClientEmail() {
        return clientEmail;
    }

    /**-------------------------Setters-------------------------------------------------------------**/
    public void setId(String id) { this.id=id;}

    public void setState(States state) {
        this.state = state;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public void setDestiation(String destination) {
        this.destination = destination;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public void setClientPhone(String clientPhone) {
        this.clientPhone = clientPhone;
    }

    public void setClientEmail(String clientEmail) {
        this.clientEmail = clientEmail;
    }

    /**
     * toString function that represents the class Driver
     * @return String
     */
    @Override
    public String toString() {
        return "Travel"+ "{"+
                "state=" + state +'\n'+
                ", startLocation='" + startLocation + '\n' +
                ", destination='" + destination + '\n'+
                ", startTime=" + startTime + '\n'+
                ", endTime=" + endTime + '\n'+
                ", clientName=" + clientName +  '\n'+
                ", clientPhone=" + clientPhone + '\n'+
                ", clientEmail=" + clientEmail ;
    }

    /**
     * function toStringLocation that represents the start point and destination of the user
     * @return String
     */
    public String toStringLocation() {
        return  "Start Location: " + startLocation + '\n' +
                "Destination: " + destination + '\n';
    }

    /**
     *function toStringClientDetails that represents the information of the client: name, phone and email
     * @return String
     */
    public String toStringClientDetails() {
        return "Name: " + clientName + '\n' +
                "Phone: " + clientPhone + '\n'+
                "Email: " + clientEmail;
    }

    /**
     * function equals to check if two travels are equal
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Travel travel = (Travel) obj;
        return this.getId().equals(travel.getId());
    }
}



