package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Frag2.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Frag2#} factory method to
 * create an instance of this fragment.
 */
public class Frag2 extends Fragment {
    private  String clientPhone;
    private String numPhone;
    private Travel travelDetails;

    /**
     * default ctor
     */
    public Frag2() {
        // Required empty public constructor
    }

    /**
     * function onCreateView to inflate the layout in this fragment
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //connection to firebase
        final Backend backend=new BackendFactory().getInstance(getActivity());

        final View view=inflater.inflate(R.layout.fragment_frag2, container, false);

        //finc 3 buttons
        final Button distanceButton=(Button) view.findViewById(R.id.do_distance);
        final Button startButton=(Button)view.findViewById(R.id.do_start);
        final Button finishButton=(Button)view.findViewById(R.id.do_finish);

        //update teh visibility of the buttons in function the choice in the nav menu
        String help=((NavActivity) getActivity()).help;
        if(help.equals("available"))
        {
            distanceButton.setVisibility(View.VISIBLE);
        }
        if(help.equals("drivers"))
        {
            startButton.setVisibility(View.VISIBLE);
            finishButton.setVisibility(view.VISIBLE);
        }
        //get all information whose were keep
        Bundle bundle=getArguments();
        //if there are not empty so get them and show them in the view
        if(!bundle.isEmpty()) {
            final Travel travelIn = (Travel) bundle.getSerializable("select");
            //check
            Toast.makeText(getContext(), travelIn.toString(), Toast.LENGTH_SHORT).show();

            /**
             * operation where we click on distance button
             */
            distanceButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    travelIn.setState(Travel.States.TREATMENT);
                    travelIn.setId(((NavActivity) getActivity()).driverNow.getId());
                    backend.updateTravel(travelIn);

                    clientPhone = travelIn.getClientPhone();
                    numPhone = ((NavActivity) getActivity()).driverNow.getPhone();
                }
            });
            /**
             * operation where we click on start button
             */
            startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    backend.updateTravel(travelIn);
                    startButton.setVisibility(View.INVISIBLE);
                }
            });

            /**
             * operation where we click on finish button
             */
            finishButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    travelIn.setState(Travel.States.FINISH);
                    backend.updateTravel(travelIn);
                    finishButton.setVisibility(View.INVISIBLE);
                    startButton.setVisibility(View.INVISIBLE);
                }
            });

            //set all information on the view
            TextView state = (TextView) view.findViewById(R.id.in_state);
            state.setText(travelIn.getState().name());

            TextView startPoint = (TextView) view.findViewById(R.id.in_start);
            startPoint.setText(travelIn.getStartLocation());

            TextView dest = (TextView) view.findViewById(R.id.in_dest);
            dest.setText(travelIn.getDestination());

            TextView clientName = (TextView) view.findViewById(R.id.in_client_name);
            clientName.setText(travelIn.getClientName());

            TextView clientPhone = (TextView) view.findViewById(R.id.in_client_phone);
            clientPhone.setText(travelIn.getClientPhone());
        }
        return view;

    }

    /* TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
    }

    @Override
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }*/

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
