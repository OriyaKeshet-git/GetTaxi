package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NavActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    //connection to firebase
    Backend backend= BackendFactory.getInstance(this);

    //choice of operations of nav menu
    public String help="nothing";

    Driver driverNow=new Driver();
    public ArrayList<Travel> navList=new ArrayList<>();

    //Location
    LocationManager locationManager;//location manager
    LocationListener locationListener;//listener to the location if there is updating
    TextView locationTextView;//text of the location

    public Address driverLocation;

    /**
     * function onCreate to initialize the view
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav);

        //get the information of the user
        String username="";
        String password ="";
        Bundle extras=getIntent().getExtras();
        username=extras.getString("username");
        password=extras.getString("password");

        //pass of all dirvers in database and get the first of them which correspond to username and password of the user
        for(Driver driver: backend.getDrivers())
        {
            if(username.equals(driver.getUsername()) && password.equals(driver.getPassword())) {
                driverNow = driver;
                break;
            }

        }
        //a driver
        Driver driver=new Driver("ankonina", "ankonina", "ankonina","morgane","208883884", "0586808006","ankos@hotmail.com","123456789" );
        driverNow=driver;
        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //drawerLayout
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        //navigationView
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //initialization the fragments: clear all last information (of the last selections)
        android.support.v4.app.FragmentManager fragmentManager1=getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
        BasicFragment frag1=new BasicFragment();
        fragmentTransaction1.add(R.id.contain_frag1, frag1 ,"fragment1");
        fragmentTransaction1.commit();

        android.support.v4.app.FragmentManager fragmentManager2=getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction2=fragmentManager2.beginTransaction();
        BasicFragment frag2=new BasicFragment();
        //fragmentTransaction2.replace(R.id.contain_frag2,frag2,"fragment2");
        fragmentTransaction2.add(R.id.contain_frag2, frag2);
        fragmentTransaction2.commit();

        //call the function createLocation to find the location
        createLocation();
    }

    /**
     * function getLocation to get the location after request permission to lication
     */
    public void getLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 5);
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,locationListener);
        }
    }

    /**
     * function createLocation to define a listener to location
     */
    private void createLocation() {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        //define a listener that responds to location updates
        locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                locationTextView = (TextView) findViewById(R.id.text_start_frag1);
                locationTextView.setText(getPlace(location));////location.toString());
                // delete the listener which wqs defined
                locationManager.removeUpdates(locationListener);
            }
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }
            public void onProviderEnabled(String provider) {
            }
            public void onProviderDisabled(String provider) {
            }
        };
    }

    /**
     * function getPlace to convert the location to String value
     * @param location that we found by gps
     * @return string of the location
     */
    public String getPlace(Location location) {

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);

            if (addresses.size() > 0) {
                String cityName = ""+addresses.get(0).getAddressLine(0);
                return cityName;
            }
            return "No place: \n ("+location.getLongitude()+" , "+location.getLatitude()+")";
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        return "The place is invalid, please try again";
    }


    /**
     * function onRequestPermissionsResult to get a permission
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 5) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            } else {
                Toast.makeText(this, "Until you grant the permission, we cannot display the location", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * function onBackPressed
     */
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    /**
     * function onCreateOptionsMenu to infate the menu with all options (available travels, my travels and exit)
     * @param menu
     * @return boolean
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.nav, menu);
        return true;
    }

    /**
     * function onOptionsItemSelected for options of toolbar (help)
     * @param item
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //we get to the website of getTaxi
        if (id == R.id.help) {
            Intent help= new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://gett.com/il/faq/drivers/"));
            startActivity(help);
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * function onNavigationItemSelected to each item of the nav menu
     * @param item
     * @return boolean
     */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        //close the nav view after we choose the item we want to show
        DrawerLayout drawerLayout=(DrawerLayout) findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);

        int id = item.getItemId();

        android.support.v4.app.FragmentManager fragmentManager=getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        BasicFragment frag=new BasicFragment();
        fragmentTransaction.replace(R.id.contain_frag2,frag);
        fragmentTransaction.commit();

        //if the user choose available travels
        if (id == R.id.nav_avTravels) {
            help="available";
            //all available travels from firebase
            navList=backend.getAvailableTravel();
            //check the list is not empty
            //String size= String.valueOf( navList.size());
            //Toast.makeText(this, size, Toast.LENGTH_SHORT).show();
            //navList=backend.getTravelDriver(driverNow.getId());
            android.support.v4.app.FragmentManager fragmentManager1=getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
            Frag1 frag1=new Frag1();
            fragmentTransaction1.replace(R.id.contain_frag1,frag1);
            fragmentTransaction1.commit();

        }
        //if the user choose my travels
        else if (id == R.id.nav_myTavels) {
            help="drivers";
            //get all travels of the current driver
            navList=backend.getTravelDriver(driverNow.getId());
            android.support.v4.app.FragmentManager fragmentManager1=getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction fragmentTransaction1=fragmentManager1.beginTransaction();
            Frag1 frag1=new Frag1();
            fragmentTransaction1.replace(R.id.contain_frag1,frag1);
            fragmentTransaction1.commit();
        }
        //if the user choose to exit
        else if (id == R.id.nav_exit) {
            finish();
            moveTaskToBack(true);
        }
        //close the drawerLayout
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
