package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.datasource.DataBaseFB;

import java.util.ArrayList;

import static com.example.morganeankonina.android5779quickly_3884_9325_5513.control.HelpService.CHANNEL_ID;

public class MyService extends Service {
     private MediaPlayer player;

    @Override
    public void onCreate() {
        super.onCreate();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        //SERVICE MEDIA
        /*player= MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
        player.setLooping(true);
        player.start();*/

        String input = intent.getStringExtra("inputExtra");
        //from MyService to MainActivity
        Intent notificationIntent = new Intent(this, MainActivity.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        //settings of notification
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Service")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_android_service)
                .setContentIntent(pendingIntent)
                .build();

        ContextCompat.startForegroundService(this, notificationIntent);
        return START_NOT_STICKY;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        //player.stop();
    }
}



