package com.example.morganeankonina.android5779quickly_3884_9325_5513.model.datasource;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Travel;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;


import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Toast;


import java.sql.Time;
import java.util.ArrayList;

import java.util.ArrayList;

import static java.sql.DriverManager.println;


public class DataBaseList implements Backend {

    ArrayList<Driver> drivers=new ArrayList<>();

    /**
     * ctor
     */
    public DataBaseList(){
        Driver driver = new Driver("ankonina", "ankonina","ANKONINA","Morgane", "208883884","0586808006","ankoninam@hotmail.com", "123456789");
        drivers.add(driver);
    }

    @Override
    public ArrayList<Travel> getTravels() {
        return null;
    }

    /**
     * function getAvailableTravel to get all available travels: state=TREATMENT
     * @return list of available travels
     */
    @Override
    public ArrayList<Travel> getAvailableTravel() {
        ArrayList<Travel> allTravels = new ArrayList<>();
        //define four travels and add them to array list to check
        Travel travel1 = new Travel(Travel.States.FREE, "Ashdood", "Jerusalem", "8:00","10:00", "Morgane", "0586808006", "ankoninam@hotmail.com");
        Travel travel2 = new Travel(Travel.States.TREATMENT, "Ashkelon", "Ashdood","8:00","10:00", "Yehouda", "0586808006", "yehouda@hotmail.com");
        Travel travel3 = new Travel(Travel.States.TREATMENT, "Eilat", "Tel Aviv", "8:00","10:00", "Aaron", "0586808006", "aaron@hotmail.com");
        Travel travel4 = new Travel(Travel.States.FINISH, "Natanya", "Ashdood","8:00","10:00", "Nethanel", "0586808006", "nethanel@hotmail.com");

        allTravels.add(travel1);
        allTravels.add(travel2);
        allTravels.add(travel3);
        allTravels.add(travel4);

        ArrayList<Travel> availableTravels = new ArrayList<>();
        //pass of all travels and take travels in treatment
        for (Travel travel : allTravels) {
            if (travel.getState() == Travel.States.TREATMENT)
                availableTravels.add(travel);
        }
        return availableTravels;
    }

    /**
     * function getFinishTravel to get all finished travels: state=FINISHED
     * @return list of finished travels
     */
    @Override
    public ArrayList<Travel> getFinsishTravel() {
        ArrayList<Travel> allTravels = new ArrayList<>();
        //define fout travels and add them to array list to check
        Travel travel1 = new Travel(Travel.States.FREE, "Ashdood", "Jerusalem", "8:00","10:00", "Morgane", "0586808006", "ankoninam@hotmail.com");
        Travel travel2 = new Travel(Travel.States.TREATMENT, "Ashkelon", "Ashdood","8:00","10:00", "Yehouda", "0586808006", "yehouda@hotmail.com");
        Travel travel3 = new Travel(Travel.States.TREATMENT, "Eilat", "Tel Aviv", "8:00","10:00", "Aaron", "0586808006", "aaron@hotmail.com");
        Travel travel4 = new Travel(Travel.States.FINISH, "Natanya", "Ashdood","8:00","10:00", "Nethanel", "0586808006", "nethanel@hotmail.com");

        allTravels.add(travel1);
        allTravels.add(travel2);
        allTravels.add(travel3);
        allTravels.add(travel4);

        ArrayList<Travel> finishTravels = new ArrayList<>();
        //pass of all travel and take travels finished
        for (Travel travel : allTravels) {
            if (travel.getState() == Travel.States.FINISH)
                finishTravels.add(travel);
        }
        return finishTravels;
    }

    /**
     * function getTravelDriver to get all travels of driver
     * @param driverId
     * @return list of driver's travels
     */
    @Override
    public ArrayList<Travel> getTravelDriver(String driverId) {
        ArrayList<Travel> allTravels = new ArrayList<>();
        //define four travels and add them to array list to check
        Travel travel1 = new Travel(Travel.States.FREE, "Ashdood", "Jerusalem", "8:00","10:00", "Morgane", "0586808006", "ankoninam@hotmail.com");
        Travel travel2 = new Travel(Travel.States.TREATMENT, "Ashkelon", "Ashdood","8:00","10:00", "Yehouda", "0586808006", "yehouda@hotmail.com");
        Travel travel3 = new Travel(Travel.States.TREATMENT, "Eilat", "Tel Aviv", "8:00","10:00", "Aaron", "0586808006", "aaron@hotmail.com");
        Travel travel4 = new Travel(Travel.States.FINISH, "Natanya", "Ashdood","8:00","10:00", "Nethanel", "0586808006", "nethanel@hotmail.com");

        allTravels.add(travel1);
        allTravels.add(travel2);
        allTravels.add(travel3);
        allTravels.add(travel4);

        ArrayList<Travel> travelByIdDrivers = new ArrayList<>();
        //pass of all travels and take travels of a specific driver
        for (Travel travel : allTravels) {
            if (driverId.equals(travel.getId()) )
                travelByIdDrivers.add(travel);
        }
        return travelByIdDrivers;
    }

    @Override
    public ArrayList<Travel> getTravelCity(String city) {
        ArrayList<Travel> allTravels = new ArrayList<>();
        //define four travels and add them to array list to check
        Travel travel1 = new Travel(Travel.States.FREE, "Ashdood", "Jerusalem", "8:00","10:00", "Morgane", "0586808006", "ankoninam@hotmail.com");
        Travel travel2 = new Travel(Travel.States.TREATMENT, "Ashkelon", "Ashdood","8:00","10:00", "Yehouda", "0586808006", "yehouda@hotmail.com");
        Travel travel3 = new Travel(Travel.States.TREATMENT, "Eilat", "Tel Aviv", "8:00","10:00", "Aaron", "0586808006", "aaron@hotmail.com");
        Travel travel4 = new Travel(Travel.States.FINISH, "Natanya", "Ashdood","8:00","10:00", "Nethanel", "0586808006", "nethanel@hotmail.com");

        allTravels.add(travel1);
        allTravels.add(travel2);
        allTravels.add(travel3);
        allTravels.add(travel4);

        ArrayList<Travel> travelByCityDrivers = new ArrayList<>();
        for (Travel travel : allTravels) {
            if (travel.getStartLocation().equals(city))
                travelByCityDrivers.add(travel);
        }
        return travelByCityDrivers;
    }
    /**
     * function addDriver to add driver to array list of drivers
     * @param driver
     */
    @Override
    public void addDriver(Driver driver) throws Exception {
        try{
            drivers.add(driver);
        }
        catch (Exception e)
        {
           println("We can't add the driver! Try again");
        }
    }

    /**
     * function getDrivers to get al drivers
     * @return list of all drivers
     */
    @Override
    public ArrayList<Driver> getDrivers() {
        return drivers;
    }

    /**
     * function getNamesDrivers to get all driver with the same name
     * @param driverName
     * @return list of drivers with specific name
     */
    @Override
    public ArrayList<Driver> getNamesDrivers(String driverName) {
        ArrayList<Driver> driversName = new ArrayList<>();
        //pass of all drivers and take all drivers with the same name
        for (Driver driver : drivers) {
            if (driver.getName().equals(driverName))
                driversName.add(driver);
        }
        return driversName;
    }

    /**
     * function getAvailablelTravelKm to get all travels in function of a specific distance in km
     * @param context
     * @param driverLocation
     * @param km
     * @return list of travels in function of a specific distance in km
     */
    @Override
    public ArrayList<Travel> getAvailableTravelKm(Context context, String driver, int km) {
        Travel travel1 = new Travel(Travel.States.FREE, "Ashdood", "Jerusalem", "8:00","10:00", "Morgane", "0586808006", "ankoninam@hotmail.com");
        Travel travel2 = new Travel(Travel.States.TREATMENT, "Ashkelon", "Ashdood","8:00","10:00", "Yehouda", "0586808006", "yehouda@hotmail.com");
        Travel travel3 = new Travel(Travel.States.TREATMENT, "Eilat", "Tel Aviv", "8:00","10:00", "Aaron", "0586808006", "aaron@hotmail.com");
        Travel travel4 = new Travel(Travel.States.FINISH, "Natanya", "Ashdood","8:00","10:00", "Nethanel", "0586808006", "nethanel@hotmail.com");

        ArrayList<Travel> driversKm=new ArrayList<Travel>();
        driversKm.add(travel1);
        driversKm.add(travel2);
        driversKm.add(travel3);
        return  driversKm;
    }

    /**
     * function updateTravel
     * @param toUpdate
     */
    @Override
    public void updateTravel(Travel toUpdate) {
    }
}




