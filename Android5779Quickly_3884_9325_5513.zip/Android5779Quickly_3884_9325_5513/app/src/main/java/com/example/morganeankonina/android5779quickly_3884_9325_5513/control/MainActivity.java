package com.example.morganeankonina.android5779quickly_3884_9325_5513.control;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morganeankonina.android5779quickly_3884_9325_5513.R;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.entities.Driver;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.Backend;
import com.example.morganeankonina.android5779quickly_3884_9325_5513.model.backend.BackendFactory;

/**
 * class MainActivity
 */
public class MainActivity extends AppCompatActivity {

    /**
     * function onCreate to initialize the view
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connection to firebase
        final Backend backend = BackendFactory.getInstance(this);

        final TextView usernameText = (TextView) findViewById(R.id.login_username);
        final TextView passwordText = (TextView) findViewById(R.id.login_password);

        final Button service_button=(Button) findViewById(R.id.service);
        /**
         * operation where we click on service_button button-service start
         */
        service_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(v);
            }
        });

        final TextView registerOk = (TextView) findViewById(R.id.login_reg_text);

        /**
         * operation where we click on registerOk button
         * when user click on don't have account the user enters all information and the function adds them to dataBase
         */
        registerOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent register = new Intent(MainActivity.this, RegisterActivity.class);
                    startActivity(register);

                } catch (Exception e) {
                    Toast toast = Toast.makeText(getApplicationContext(), e.getMessage() + "No success from MainActivity to Register", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });

        final Button signIn = (Button) findViewById(R.id.login_signIn);
        /**
         * operation where we click on signIn button
         * the user sign to his count with his username and password
         */
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //check
                    //Toast toast = Toast.makeText(getApplicationContext(), usernameText.getText().toString()+passwordText.getText().toString(), Toast.LENGTH_LONG);
                    //toast.show();
                    //Driver d=new Driver(usernameText.toString(), passwordText.toString());
                    Driver driver =new Driver(usernameText.getText().toString(), passwordText.getText().toString());
                    // if (exists(usernameText.getText().toString(), passwordText.getText().toString())==true) {
                    //if this user exists on the database
                    if(exists(driver)==true)
                    {
                        //keep this information to next time where he want to connect
                        SharedPreferences prefs = getSharedPreferences("sharedPreferences", MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();

                        editor.putString("username", usernameText.getText().toString());
                        editor.putString("password", passwordText.getText().toString());
                        editor.commit();
                        //Toast.makeText(getBaseContext(), "saved information: username and password", Toast.LENGTH_LONG).show();

                        //from MainActivity to NavActivity
                        Intent goNav = new Intent(MainActivity.this, NavActivity.class);
                        Bundle extras = new Bundle();
                        extras.putString("username", usernameText.getText().toString());
                        extras.putString("password", passwordText.getText().toString());
                        goNav.putExtras(extras);
                        startActivity(goNav);
                    }
                    //if the user doesn't exist in dataBase
                    else {
                       Toast.makeText(getApplicationContext(), "The user doesn't exist! Please enter again or register", Toast.LENGTH_LONG).show();
                   }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        //show last identifiers of the user-last connection
        SharedPreferences prefs = getSharedPreferences("sharedPreferences", MODE_PRIVATE);
        usernameText.setText(prefs.getString("username", ""));
        passwordText.setText(prefs.getString("password", ""));

    }

    /**
     * function exists to check if the user exists in dataBase and if his identifiers are correct
     * @param driver
     * @return boolean true if there are driver is already exists and false if he is not already exists
     */
    public boolean exists(final Driver driver)//take details rhat were entered and try to check if exist in system
    {
        final Backend backend=BackendFactory.getInstance(this);
        // pass in all drivers in dataBase
        for (Driver d : backend.getDrivers())
        {
            //Toast.makeText( this, d.toString(), Toast.LENGTH_LONG).show();
            if(d.equals(driver))
                return true;
        }
        return false;
    }

    /**
     * function startService to start the service and notification of the service
     * @param view
     */
    public void startService(View view)
    {
        final TextView usernameText = (TextView) findViewById(R.id.login_username);
        final TextView passwordText = (TextView) findViewById(R.id.login_password);

        String input="Hello"+usernameText.getText().toString();
        Toast.makeText(this, input, Toast.LENGTH_SHORT).show();
        //from MainActivity to MyService
        Intent serviceIntent=new Intent(this, MyService.class);
        serviceIntent.putExtra("inputExtra", input);
        //ContextCompat.startForegroundService(this, serviceIntent);
        startService(serviceIntent);
    }

    /**
     * fucntion stopService to stop the service in the foreground
     * @param v
     */
    public void stopService(View v)
    {
        Intent serviceIntent=new Intent(this, MyService.class);
        stopService(serviceIntent);
    }
}

